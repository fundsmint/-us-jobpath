US JOBPATH — STARTER WEBSITE
============================

CONTENTS
- index.html: homepage
- styles.css: responsive visual design
- script.js: mobile navigation, guide search, current year
- about.html, contact.html, privacy.html, disclaimer.html: basic information pages
- guides/: six starter career articles

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open index.html in a web browser. On a phone, you may need a file manager or a computer for easiest preview.
3. To edit text, open the relevant .html file in a text editor.
4. To change design, edit styles.css.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create an account at https://github.com/
2. Create a new public repository, for example: us-jobpath
3. Upload all files and folders from this ZIP. Keep index.html at the repository root.
4. In the repository, open Settings > Pages.
5. Under build/deployment, choose deploy from a branch, select the main branch and root folder, then save.
6. Wait for GitHub Pages to publish and use the address shown in Settings > Pages.
GitHub's screens may change; follow its current Pages instructions. A custom domain is optional and usually costs money.

IMPORTANT BEFORE LAUNCH
- “US JobPath” is a working name; check name and domain availability before using it commercially.
- The site currently contains educational guides, not live job vacancies. Do not advertise it as a live job board until verified listings and an update process exist.
- Pay examples are illustrative. Verify all pay, eligibility, vacancy status, and sponsorship claims using official sources.
- Add a contact email you control and customise the privacy/disclaimer pages to match the final site and services.
- Google Fonts needs an internet connection; the site still works with fallback fonts.
- No newsletter, contact form, database, job submission system, or live vacancy feed is connected yet.
- Review current laws and platform requirements before monetising or collecting personal information.

NEXT BUILD PHASE
1. Add researched, verified job opportunities with official application links.
2. Add article SEO titles, canonical URLs, sitemap.xml, robots.txt, and a favicon.
3. Connect a contact form and newsletter only when you have chosen a trusted provider and updated the privacy notice.
4. Add analytics/advertising only after reviewing consent, privacy, and publisher requirements.
